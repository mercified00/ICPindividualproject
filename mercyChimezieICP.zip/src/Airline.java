public class Airline{
    /**
     * Instance variables for the Airline class
     */
    private final int airlineId;
    private final String name;
    private final String alias;
    private final String iatacode;
    private final String icaocode;
    private final String callsign;
    private final String country;
    private final String active;

    /**
     *
     * @param airlineId the ID of the airline
     * @param name the name of the airline
     * @param alias is the alias of the airline
     * @param iatacode two letter IATA code if available
     * @param icaocode three letter ICAO code if available
     * @param callsign airline callsign
     * @param country country where airport is located
     * @param active "y" if airline has been recently functional, and "n" if it has been defunct
     */

    public Airline(int airlineId, String name, String alias, String iatacode, String icaocode, String callsign,
                   String country, String active){
        this.airlineId = airlineId;
        this.name = name;
        this.alias = alias;
        this.iatacode = iatacode;
        this.icaocode = icaocode;
        this.callsign = callsign;
        this.country = country;
        this.active = active;
    }

    public Airline() {
        this.airlineId = 0;
        this.name = "";
        this.alias = "";
        this.iatacode = "";
        this.icaocode = "";
        this.callsign = "";
        this.country = "";
        this.active = "";

    }

    /**
     *
     * @return toString method
     */
    @Override
    public String toString() {
        return "Airline{" +
                "airlineId=" + airlineId +
                ", name='" + name + '\'' +
                ", alias='" + alias + '\'' +
                ", iatacode='" + iatacode + '\'' +
                ", icaocode='" + icaocode + '\'' +
                ", callsign='" + callsign + '\'' +
                ", country='" + country + '\'' +
                ", active='" + active + '\'' +
                '}';
    }

    /**
     *
     * @return getters method
     */
    public int getAirlineId() {
        return airlineId;
    }

    public String getName() {
        return name;
    }

    public String getAlias() {
        return alias;
    }

    public String getIatacode() {
        return iatacode;
    }

    public String getIcaocode() {
        return icaocode;
    }

    public String getCallsign() {
        return callsign;
    }

    public String getCountry() {
        return country;
    }

    public String isActive() {
        return active;
    }
}
