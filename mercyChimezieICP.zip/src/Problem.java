import java.util.ArrayList;
import java.util.Objects;

public class Problem{
    private  final int init_state;
    private final int goal_state;
    private final ArrayList<Route> mymap;

    public Problem(int init_state, int goal_state, ArrayList<Route> mymap){
        this.init_state = init_state;
        this.goal_state = goal_state;
        this.mymap = mymap;
    }

    public int getInit_state() {
        return init_state;
    }

    public int getGoal_state() {
        return goal_state;
    }

    public ArrayList<Route> getMap() {
        return mymap;
    }

    public boolean goal_test(int state){
        return (Objects.equals(this.goal_state, state));
    }

    public ArrayList<Integer> actions(int state){
        ArrayList<Integer> neighbours = new ArrayList<>();
        for (Route object: this.mymap) {
            if (state == object.getSourceairportid()) {
                neighbours.add(object.getDestairportid());
            }
        }
        return neighbours;

    }
}
