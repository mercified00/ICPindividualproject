public class Airport {
    /**
     * Instance Variables for the Airport Class
     */
    private final int airportID;
    private final String name;
    private final String city;
    private final String country;
    private final String iataCode;
    private final String icaoCode;
    private final double latitude;
    private final double longitude;
    private final double altitude;
    private final double timezone;
    private final String DST;
    private final String tz;
    private final String type;
    private final String datasource;

    /**
     * @author Mercy Chimezie
     * @param airportID is the ID of the airport
     * @param name is the name of the airport
     * @param city is the city where the airport is located
     * @param country is the country where the airport is located
     * @param iataCode three-letter IATA code. Null if not assigned
     * @param icaoCode four-letter ICAO code. Null if not assigned
     * @param latitude 	Decimal degrees, usually to six significant digits. Negative is South, positive is North.
     * @param longitude Decimal degrees, usually to six significant digits. Negative is West, positive is East.
     * @param altitude Height in feet
     * @param timezone Hours offset from UTC. Fractional hours are expressed as decimals, eg. India is 5.5.
     * @param DST Daylight Saving time
     * @param tz Timezone in tz olson format
     * @param type Type of the airport
     * @param datasource Source of this data
     */


    public Airport(int airportID, String name, String city, String country, String iataCode,
                   String icaoCode, double latitude, double longitude, double altitude,
                   double timezone, String DST, String tz, String type, String datasource) {
        this.airportID = airportID;
        this.name = name;
        this.city = city;
        this.country = country;
        this.iataCode = iataCode;
        this.icaoCode = icaoCode;
        this.latitude = latitude;
        this.longitude = longitude;
        this.altitude = altitude;
        this.timezone = timezone;
        this.DST = DST;
        this.tz = tz;
        this.type = type;
        this.datasource = datasource;
    }


    public Airport() {
        this.airportID = 0;
        this.name = "";
        this.city = "";
        this.country = "";
        this.iataCode = "";
        this.icaoCode = "";
        this.latitude = 0.0;
        this.longitude = 0.0;
        this.altitude = 0.0;
        this.timezone = 0.0;
        this.DST = "";
        this.tz = "";
        this.type = "";
        this.datasource = "";
    }

    /**
     *
     * @return toString method
     */
    @Override
    public String toString() {
        return "Airport{" +
                "airportID=" + airportID +
                ", name='" + name + '\'' +
                ", city='" + city + '\'' +
                ", country='" + country + '\'' +
                ", iataCode='" + iataCode + '\'' +
                ", icaoCode='" + icaoCode + '\'' +
                ", latitude=" + latitude +
                ", longitude=" + longitude +
                ", altitude=" + altitude +
                ", timezone=" + timezone +
                ", DST='" + DST + '\'' +
                ", tz='" + tz + '\'' +
                ", type='" + type + '\'' +
                ", datasource='" + datasource + '\'' +
                '}';
    }

    /**
     *
     * @return getters method
     */
    public int getAirportID() {
        return airportID;
    }

    public String getName() {
        return name;
    }

    public String getCity() {
        return city;
    }

    public String getCountry() {
        return country;
    }

    public String getIataCode() {
        return iataCode;
    }

    public String getIcaoCode() {
        return icaoCode;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public double getAltitude() {
        return altitude;
    }

    public double getTimezone() {
        return timezone;
    }

    public String getTz() {
        return tz;
    }

    public String getType() {
        return type;
    }

    public String getDatasource() {
        return datasource;
    }

    public String getDST(){
        return DST;
    }

}
