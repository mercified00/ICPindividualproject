import java.io.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Main {
    public static ArrayList<Airport> airportArrayObj = new ArrayList<>();
    public static ArrayList<Airline> airlineArrayObj = new ArrayList<>();
    public static ArrayList<Route> routeArrayObj = new ArrayList<>();
    /**
     *Driver Code
     */
    public static void main(String[] args) {
        ArrayList<String[]> airportStringArray = new ArrayList<>(
                readAndWrite.readFile("C:\\Users\\Mercy Chimezie\\IdeaProjects\\myICPproject\\src\\airports.csv"));
        for (String[] array : airportStringArray) {
            Airport object = theObjects.airportObjectCreation(array);
            airportArrayObj.add(object);
        }
        ArrayList<String[]> airlineStringArray = new ArrayList<>(
                readAndWrite.readFile("C:\\Users\\Mercy Chimezie\\IdeaProjects\\myICPproject\\src\\airlines.csv"));
        for (String[] array : airlineStringArray) {
            Airline object = theObjects.airlineObjectCreation(array);
            airlineArrayObj.add(object);
        }
        ArrayList<String[]> routeStringArray = new ArrayList<>(
                readAndWrite.readFile("C:\\Users\\Mercy Chimezie\\IdeaProjects\\myICPproject\\src\\routes.csv"));
        for (String[] array : routeStringArray) {
            Route object = theObjects.routesObjectCreation(array);
            routeArrayObj.add(object);
        }
        /*
        Print out all the created objects to view if you wish.
         */
//        System.out.println(airportArrayObj);
//        System.out.println(airlineArrayObj);
//        System.out.println(routeArrayObj);
        /*
        Read from the file
         */
        ArrayList<String[]> input = readAndWrite.readFile("src/Accra-Winnipeg");
        String[] sourceAirport = input.get(0);
        ArrayList<Integer> sAirportIDs = theObjects.AirportIDbyCityCountry(sourceAirport[0].trim(), sourceAirport[1].trim());

        String[] destinationAirport = input.get(1);
        ArrayList<Integer> dAirportIDs = theObjects.AirportIDbyCityCountry(destinationAirport[0].trim(), destinationAirport[1].trim());

        /*
        Using the Uniform cost Algorithm, get the route from your starting airport to the destination airport
         */

        ArrayList<Paths> possiblePaths = new ArrayList<>();
        for (Integer sAirportID: sAirportIDs) {
            for (Integer dAirportID: dAirportIDs) {
                Problem prob = new Problem(sAirportID, dAirportID, routeArrayObj);
                Paths result = algorithm.uCs(prob);
                if (result != null) {
                    possiblePaths.add(result);
                }
            }
        }

        Collections.sort(possiblePaths);
        Paths bestPath = possiblePaths.get(0);

        System.out.println(bestPath.getActionSequence());
        StringBuilder data = new StringBuilder();
        int numIterations = 0;
        int stops = 0;
        for (Integer AirportID: bestPath.getActionSequence()) {
            for (Route route: routeArrayObj) {
                ArrayList<Route> possibleDestinations = new ArrayList<>();
                if (route.getSourceairportid() == AirportID) {
                    possibleDestinations.add(route);
                }
                for (Route possibleRoute: possibleDestinations) {
                    if (numIterations < (bestPath.getActionSequence().size())) {
                        if (possibleRoute.getSourceairportid() == bestPath.getActionSequence().get(numIterations)) {
                            data.append((numIterations) + ". " +
                                 possibleRoute.getAirlinecode() + " from " +
                                 theObjects.getAirport(possibleRoute.getSourceairportid(), airportArrayObj).getIataCode() + " to " +
                                 theObjects.getAirport(possibleRoute.getDestairportid(), airportArrayObj).getIataCode() + " " +
                                 possibleRoute.getStops()).append(" stops.\n"
                            );
                            numIterations++;
                            stops += possibleRoute.getStops();
                        }
                    }
                }
            }

        }

        data.append("\nTotal flights: ").append(numIterations);
        data.append("\nTotal additional stops: ").append(stops);
        data.append("\nTotal distance: ").append(bestPath.getPathCost()).append(" km");
        data.append("\nOptimality criteria: distance");

        System.out.println(data);
        readAndWrite.writeToFile("src/Accra-Winnipeg-output.txt", data.toString());

        System.out.println();
    }
}
/**
 * This class is used to read from the file and write into the file
 */
class readAndWrite {
    public static ArrayList<String[]> readFile(String filePathName) {
        ArrayList<String[]> ArrayString = new ArrayList<>();
        try{
            File fileObj = new File(filePathName);
            BufferedReader br = new BufferedReader(new FileReader(fileObj));
            String line;

            while ((line = br.readLine()) != null){
                String [] objectArray = line.split(",");
                ArrayString.add(objectArray);
            }
            br.close();
        }catch (FileNotFoundException fn){
            System.out.println("Error caught: " + fn.getMessage());
//            fn.printStackTrace();

        }catch (IOException io){
            System.out.println("Error Caught" + io.getMessage());
//            io.printStackTrace();
        }
        return ArrayString;
    }
    public static void writeToFile(String filenamePath, String text){

        try {
            File fileobj = new File(filenamePath);
            BufferedWriter bw = new BufferedWriter(new FileWriter(fileobj));
            String[] texts = text.split("\n");
            for (String line: texts) {
                bw.write(line);
                bw.newLine();
            }
            System.out.println("File is created successfully with the content.");
            bw.close();
        }
        catch (IOException ie) {
            System.out.print("Error Caught" + ie.getMessage());
        }
    }
}
/*
Create Objects for each of the data files
 */
class theObjects{
    public static Airport airportObjectCreation(String[] airportArray){
        int airportID = 0;
        double latitude = 0.0;
        double longitude = 0.0;
        double altitude = 0.0;
        double timezone = 0.0;
        try{
            airportID = Integer.parseInt(airportArray[0]);
            latitude = Double.parseDouble(airportArray[6]);
            longitude = Double.parseDouble(airportArray[7]);
            altitude = Double.parseDouble(airportArray[8]);
            timezone = Double.parseDouble(airportArray[9]);
        }
        catch(NumberFormatException ne){
            System.out.println("Error Caught:" + ne.getMessage());
//            ne.printStackTrace();
        }
        String name = airportArray[1];
        String city = airportArray[2];
        String country = airportArray[3];
        String iataCode = airportArray[4];
        String icaoCode = airportArray[5];
        String DST = airportArray[10];
        String tz = airportArray[11];
        String type = airportArray[12];
        String datasource = airportArray[13];

        return new Airport(
                airportID, name, city, country, iataCode, icaoCode, latitude, longitude,
                altitude, timezone, DST, tz, type, datasource);
    }
    public static Airline airlineObjectCreation(String[] airlineArray){
        int airlineId = 0;
        try{
            airlineId = Integer.parseInt(airlineArray[0]);
        }
        catch(NumberFormatException ne){
            System.out.println("Error Caught: " + ne.getMessage());
//            ne.printStackTrace();
        }
        String name = airlineArray[1];
        String alias = airlineArray[2];
        String iatacode = airlineArray[3];
        String icaocode = airlineArray[4];
        String callsign = airlineArray[5];
        String country = airlineArray[6];
        String active = airlineArray[7];

        return new Airline(airlineId, name, alias, iatacode,icaocode, callsign,
                country, active);
    }
    public static Route routesObjectCreation(String[] routeArray){
        int airlineid = 0;
        int sourceairportid = 0;
        int destairportid = 0;
        int stops = 0;
        try{
            airlineid = Integer.parseInt(routeArray[1]);
            sourceairportid = Integer.parseInt(routeArray[3]);
            destairportid = Integer.parseInt(routeArray[5]);
            stops = Integer.parseInt(routeArray[7]);
        }
        catch (NumberFormatException | ArrayIndexOutOfBoundsException ne){
            System.out.println("Error Caught" + ne.getMessage());
//            ne.printStackTrace();
        }
        String airlinecode = routeArray[0];
        String sourceairportcode = routeArray[2];
        String destairportcode = routeArray[4];
        String codeshare = routeArray[6];
        String equipment = routeArray[routeArray.length - 1];

        return new Route(airlinecode, airlineid, sourceairportcode, sourceairportid, destairportcode,
                destairportid, codeshare, stops, equipment);
    }
    /*
    Create additional methods that will be useful in solving the problem
     */
    public static Airport getAirport(int airportid, ArrayList<Airport> airportArrayObj) {
        Airport airportObj = new Airport();
        for (Airport airport : airportArrayObj) {
            if (airportid == airport.getAirportID()) {
                airportObj = airport;
            }
        }
        return airportObj;
    }
    public static Airline getAirline(int airlineid, ArrayList<Airline> airlineArrayObj) {
        Airline airlineObj = new Airline();
        for (Airline airline : airlineArrayObj) {
            if (airlineid == airline.getAirlineId()) {
                airlineObj = airline;
            }
        }
        return airlineObj;
    }
    public static Route getRoute(int airlineid, ArrayList<Route> routeArrayObj) {
        Route routeObj = new Route();
        for (Route route : routeArrayObj) {
            if (airlineid == route.getAirlineid()) {
                routeObj = route;
            }
        }
        return routeObj;
    }
    public static ArrayList<Integer> AirportIDbyCityCountry(String city, String country){
        ArrayList<Integer> IDairportarray = new ArrayList<>();
        for (Airport airport: Main.airportArrayObj) {
            if (airport.getCity().equals(city) && airport.getCountry().equals(country)) {
                IDairportarray.add(airport.getAirportID());
            }
        }

        return IDairportarray;
    }


    /** REFERENCE: Jason Winn
     * Harversine Formular Implementation
     */
    private static final int radiusEarth = 6371;
    public static double distance(double initLat, double initLong,
                                  double finalLat, double finalLong) {
        double LatDistance  = Math.toRadians((finalLat - initLat));
        double LongDistance = Math.toRadians((finalLong - initLong));
        initLat = Math.toRadians(initLat);  // convert from degrees to radians
        finalLat   = Math.toRadians(finalLat); // convert from degrees to radians
        double a = haversine(LatDistance) + Math.cos(initLat) * Math.cos(finalLat) * haversine(LongDistance);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return radiusEarth * c;
    }
    public static double haversine(double val) {
        return Math.pow(Math.sin(val / 2), 2);
    }
}
