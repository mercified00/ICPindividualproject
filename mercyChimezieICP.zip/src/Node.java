import java.util.*;
import java.util.ArrayList;
/*
This is the node class that contains the state, parent, action and pathcost
 */
public class Node {
    private final int state;
    private final Node parent;
    private final int action;
    private final double pathcost;
    public Node(int state, Node parent, int action, double pathcost) {
        this.state = state;
        this.parent = parent;
        this.action = action;
        this.pathcost = pathcost;
    }
    public Node(int init_state) {
        this.state = init_state;
        this.parent = null;
        this.action = 0;
        this.pathcost = 0;
    }
    public int getState() {
        return this.state;
    }

    public Node getParent() {
        return this.parent;
    }

    public int getAction() {
        return this.action;
    }
    public double getPathcost() {
        return pathcost;
    }

    @Override
    public String toString() {
        return "Node{" +
                "state=" + state +
                ", parent=" + parent +
                ", action=" + action +
                ", pathcost=" + pathcost +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Node node = (Node) o;
        return getState() == node.getState();
    }


    public Paths solutionPath() {
        ArrayList<Integer> actionSequence = new ArrayList<>();
        ArrayList<Integer> stateSequence = new ArrayList<>();
        double finalPathcost = this.getPathcost();
        stateSequence.add(0, this.state);
        actionSequence.add(0, this.action);

        Node node = this.parent;
        while (node != null) {
            stateSequence.add(0, node.getState());
            actionSequence.add(0, node.getAction());
            node = node.getParent();

        }
        return new Paths(actionSequence, stateSequence, finalPathcost);
    }

    public static void printFrontier(PriorityQueue<Node> frontier) {
        System.out.println("Frontier has: " + frontier.size() + " items");
        if (frontier.size() > 0) {
            Node minitem = frontier.peek();
            System.out.println(" and the min item is " + minitem.getState() + " with priority " + minitem.getPathcost());
        }
    }
}

/*
Interface for comparing two nodes
 */
class myComparable implements Comparator<Node>{
    public int compare(Node n1, Node n2) {
        return Double.compare(n1.getPathcost(), n2.getPathcost());
    }
}
class algorithm {
/*
This is a Uniform Search Algorithm that searches through the problem
 */
    public static Paths uCs(Problem problem){
        System.out.println("About to do UCS on problem: ");
        Node node = new Node(problem.getInit_state());
        PriorityQueue<Node> frontier = new PriorityQueue<>(new myComparable());
        frontier.add(node);
        HashSet<Integer> explored = new HashSet<>();


        while(frontier.size() > 0){
            node = frontier.poll();

            if(problem.goal_test(node.getState())){
                System.out.println("Found a solution" + node);
                return node.solutionPath();
            }
            else {
                explored.add(node.getState());
                System.out.println("Expanding: " + node);
                ArrayList<Integer> neighbours = problem.actions(node.getState());
    //            System.out.println("Available actions:" + neighbours);
                for (Integer neighbour : neighbours) {
                    int sourceID = node.getState();
                    int destinationID = neighbour;
                    Airport sourceAirportObj = theObjects.getAirport(sourceID, Main.airportArrayObj);
                    Airport destinationAirportObj = theObjects.getAirport(destinationID, Main.airportArrayObj);
                    double distance = theObjects.distance(sourceAirportObj.getLatitude(), sourceAirportObj.getLongitude(),
                            destinationAirportObj.getLatitude(), destinationAirportObj.getLongitude());

                    double pathCost = node.getPathcost() + distance;
                    Node child = new Node(neighbour, node, neighbour, pathCost);
                    if (!explored.contains(child.getState()) && !frontier.contains(child)) {
                        frontier.add(child);
                    } else if (frontier.contains(child)) {
                        double oldCost = frontier.peek().getPathcost();
                        if (oldCost > child.getPathcost()) {
                            frontier.poll();
                            frontier.add(child);
                        }
                    }
                }
            }
        }
        return null;
    }
}

class Paths implements Comparable<Paths> {

    ArrayList<Integer> stateSequence;
    ArrayList<Integer> actionSequence;
    double pathCost;

    public Paths(ArrayList<Integer> stateSequence, ArrayList<Integer> actionSequence, double pathCost) {
        this.stateSequence = stateSequence;
        this.actionSequence = actionSequence;
        this.pathCost = pathCost;
    }

    public ArrayList<Integer> getStateSequence() {
        return stateSequence;
    }

    public ArrayList<Integer> getActionSequence() {
        return actionSequence;
    }

    public double getPathCost() {
        return pathCost;
    }

    @Override
    public int compareTo(Paths o) {
        return Double.compare(this.getPathCost(), o.getPathCost());
    }
}



