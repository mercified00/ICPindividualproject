import java.util.*;
import java.util.ArrayList;
/*
This is the node class that contains the state, parent, action and pathcost
 */
public class Node {
    private final int state;
    private final Node parent;
    private final int action;
    private final double pathcost;
    public Node(int state, Node parent, int action, double pathcost) {
        this.state = state;
        this.parent = parent;
        this.action = action;
        this.pathcost = pathcost;
    }
    public Node(int init_state) {
        this.state = init_state;
        this.parent = null;
        this.action = 0;
        this.pathcost = 0;
    }
    public int getState() {
        return this.state;
    }

    public Node getParent() {
        return this.parent;
    }

    public int getAction() {
        return this.action;
    }
    public double getPathcost() {
        return pathcost;
    }

    @Override
    public String toString() {
        return "Node{" +
                "state=" + state +
                ", parent=" + parent +
                ", action=" + action +
                ", pathcost=" + pathcost +
                '}';
    }
    public Object[] solutionPath() {
        ArrayList<Integer> actionSequence = new ArrayList<>();
        ArrayList<Integer> stateSequence = new ArrayList<>();
        double finalPathcost = this.getPathcost();

        while (!(this.parent == null)) {
            stateSequence.add(this.parent.getState());
            actionSequence.add(this.action);
        }
        return new Object[]{actionSequence, stateSequence, finalPathcost};
    }

    public static void printFrontier(PriorityQueue<Node> frontier) {
        System.out.println("Frontier has: " + frontier.size() + " items");
        if (frontier.size() > 0) {
            Node minitem = frontier.peek();
            System.out.println(" and the min item is " + minitem.getState() + " with priority " + minitem.getPathcost());
        }
    }
}

/*
Interface for comparing two nodes
 */
class myComparable implements Comparator<Node>{
    public int compare(Node n1, Node n2) {
        return Double.compare(n1.getPathcost(), n2.getPathcost());

    }
}
class algorithm {
/*
This is a Uniform Search Algorithm that searches through the problem
 */
    public static Object[] uCs(Problem problem){
        System.out.println("About to do UCS on problem: ");
        Node node = new Node(problem.getInit_state());
        PriorityQueue<Node> frontier = new PriorityQueue<>(new myComparable());
        frontier.add(node);
        HashSet<Integer> explored = new HashSet<>();

//        Node.printFrontier(frontier);
//        System.out.println("Initially explored =" + explored);
        System.out.println();

        while(frontier.size() > 0){
            node = frontier.poll();
            if(problem.goal_test(node.getState())){
                System.out.println("Found a solution" + node);
                return node.solutionPath();
            }
            explored.add(node.getState());
            System.out.println("Expanding: " + node);
            ArrayList<Integer> neighbours = problem.actions(node.getState());
//            System.out.println("Available actions:" + neighbours);
            for (Integer neighbour : neighbours) {
                int sourceID = node.getState();
                int destinationID = neighbour;
                Airport sourceAirportObj = theObjects.getAirport(sourceID, Main.airportArrayObj);
                Airport destinationAirportObj = theObjects.getAirport(destinationID, Main.airportArrayObj);
                double distance = theObjects.distance(sourceAirportObj.getLatitude(), sourceAirportObj.getLongitude(),
                        destinationAirportObj.getLatitude(), destinationAirportObj.getLongitude());

                double pathCost = node.getPathcost() + distance;
                Node child = new Node(neighbour, node, neighbour, pathCost);
                if (!explored.contains(child.getState()) && !frontier.contains(child)) {
                    frontier.add(child);
                } else if (frontier.contains(child)) {
                    double oldCost = frontier.peek().getPathcost();
                    if (oldCost > child.getPathcost()) {
                        frontier.remove();
                        frontier.add(child);
                    }
                }
//                Node.printFrontier(frontier);
//                System.out.println("Now explored is" + explored);
//                System.out.println();
            }
        }
        return null;
    }
}



